/* LaserDTS.c
 * Laser init and main state machine
 * for 55.C4 DTS Laser, ITER CODAC
 */

/* ITER Divertor Thomson Scattering (DTS 55.C4)
 * Prototype CODAC interface part
 * STM32 to Siemens PLC RS485 Modbus part
 * HW:
 * - Siemens Simatic S7-1200 1214c DC/DC/Rly with CB 1241 RS485 Modbus board and DI/DO 16 DC
 * -- CODAC PLC Profinet API to CODAC PSH from ITER (S7-1200 from Cubicle Monitoring)
 * - STM32 dev board STM32-F746-Disco, F746G MCU, RS232<->MAX485 converter with HW flow control
 * -- STM32 Cube MX conf, STM32 IDE prog, TouchGFX GUI interface, FreeRtos
 * -- Modbus lib clone from alejoseb/Modbus-STM32-HAL-FreeRTOS
 * SW:
 * - TIA Portal V17 SW organize Modbus Master polling data through CB 1241
 * - STM32 organize Modbus Slave response from Modbus data buffer for 1 and 16 bit data and ID resp
 * - Simple logic realise for DTS diagnistic Lases functions: on/off, modbus init, change Laser settings
 * - both from Simatic side and from STM side both via GUI and internal simple Laser logic.
 * */

/* ADD for TouchGFX compile, and #ifdef TOUCHGFXDIZ
 * F746disco\TouchGFX\simulator\gcc\
 * ADDITIONAL_INCLUDE_PATHS := ../Core/Inc/
 */


#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "main.h"

#include "LaserDTS.h"
#include "LaserMB.h"

//gpio HW test functions
void UsrLedOn() {HAL_GPIO_WritePin (LED_USR_GPIO_Port, LED_USR_Pin, GPIO_PIN_SET  );}
void UsrLedOff(){HAL_GPIO_WritePin (LED_USR_GPIO_Port, LED_USR_Pin, GPIO_PIN_RESET);}
void UsrLedTog(){HAL_GPIO_TogglePin(LED_USR_GPIO_Port, LED_USR_Pin);}

//UART select and set
UART_HandleTypeDef huart1;	//ST-Lnik
UART_HandleTypeDef huart5;	//uSD-Card 485HW flow control
UART_HandleTypeDef huart6;	//Arduino conn

laserState_TypeDef ls;	//Laser FSM

#define MB_485_UART		huart1		//485 HW USART port
#define MB_485_RD_Port	GPIOB		//485 HW flow RD port
#define MB_485_RD_Pin	GPIO_PIN_8 	//485 HW flow RD pin

#define MB_AO_PW_DEF    125	//Pulse_width set default
#define MB_AO_PD_DEF    20	//Pulse_delay set default
#define MB_AO_PC_DEF    80	//Pump_current set default
#define MB_AO_CV_DEF    320	//Cap_voltage set default

//Init Modbus handler and fill MBbuffer data
void LaserInit(){
	srand(1);	//ya, im lazy

    //Modbus Slave init
    hMB.uModbusType = MB_SLAVE;			//take Slave cause Simatic is Master MB_MASTER
    hMB.xTypeHW 	= USART_HW;			//modbus physical layer = RS485
    hMB.port 		=  &MB_485_UART; 	//USART port
    hMB.u8id 		= 1;        		//Slave  ID, always !=0
    hMB.u16timeOut 	= 1000;				//
    hMB.EN_Port 	= MB_485_RD_Port; 	//RS485 port, if>1 than HW flow control
    hMB.EN_Pin  	= MB_485_RD_Pin;	//RS485 pin for HW flow control on TX telegram

    //Modbus data field init
    //link pointer to data structures
    hMB.dataDOs = MBdataDOs;  //Coils
    hMB.dataDIs = MBdataDIs;  //Inputs
    hMB.dataAOs = MBdataAOs;  //Regs holding
    hMB.dataAIs = MBdataAIs;  //Regs input
    hMB.dataSize= MBdataSize; //data size, each (DI/8, DO/8, AI or AO)
    //MBdataDIs[0]=0xAA; MBdataDIs[MBdataSize/16]=0xCC; //test data for DI
    //MBdataAIs[0]=0xBB; MBdataAIs[MBdataSize -1]=0xDD; //test data for AI

    //Init laser values
    ResetCoilDO(MB_DO_LAS_ON);
    ResetCoilDO(MB_DO_PULSE_MOD);
    ResetCoilDO(MB_DO_EXT_SYNC);
    ResetCoilDI(MB_DI_LAS_HOT);

    //Init counters
    MBdataAIs[MB_AI_MOTOH]=0;
    MBdataAIs[MB_AI_PULSC]=0;
    MBdataAIs[MB_AI_ERROR]=0;

    //Set default AI reg values
    MBdataAOs[MB_AO_PW]=MB_AO_PW_DEF;
    MBdataAOs[MB_AO_PD]=MB_AO_PD_DEF;
    MBdataAOs[MB_AO_PC]=MB_AO_PC_DEF;
    MBdataAOs[MB_AO_CV]=MB_AO_CV_DEF;
    MBdataAIs[MB_AI_PW]=0;
    //MBdataAOs[]=; //non
    MBdataAOs[MB_AI_PC]=0;
    MBdataAOs[MB_AI_CV]=0;

    //ID buffer for test ID data AB __ CD EF
    slave_id[0]=0xAB; slave_id[1]=0x00;
    slave_id[2]=0xCD; slave_id[3]=0xEF;
    hMB.dataID = slave_id;
    hMB.sizeID = sizeof(slave_id);

    //Laser ON flag
    ls.on485=1;
}

//Laser On-Off
void LaserOn(){
	ls.on=1;
	ls.hot_delay=LAS_ON_DELAY;	//->goto Heat
	UsrLedOn();
}

//Laser pre heat delay
void LaserHot(){
	ls.hot=1;
	slave_id[1]=0xFF;
	SetCoilDI(MB_DI_LAS_HOT);
}

//DeInit Laser structures
void LaserOff(){
	ls.on=0;
	ls.hot=0;
	ls.hot_delay=0;

	slave_id[1]=0x00;
	ResetCoilDI(MB_DI_LAS_HOT);

	MBdataAIs[MB_AO_PW]=0;
	MBdataAIs[MB_AO_PC]=0;
	MBdataAIs[MB_AO_CV]=0;

	UsrLedOff();
}

//GUI->Laser On/Off
void TogLaser(){
	if (ls.on) ResetCoilDO(MB_DO_LAS_ON);
		  else SetCoilDO  (MB_DO_LAS_ON);
}

//GUI->Laser, 485 UART, stop receiving, direct set NVIC
void Tog485(){
	if (ls.on485)
		{HAL_NVIC_DisableIRQ(USART1_IRQn);
		ls.on485=0;
		//ResetBit(state485,MASK_485_ON);
		}
	else{HAL_NVIC_EnableIRQ (USART1_IRQn);
		ls.on485=1;
		//SetBit(state485,MASK_485_ON);
		}
	//changed485=1; //already toggled in GUI
}


//Modbus RS485 events callback HW->Laser------------------------

//NVIC Tx/RX CpltCallbacks and Modbus validateRequest parser error
//void HW485_ONevnt(){SetBit(state485,MASK_485_ON); changed485=1;}
void HW485_TXcplt(){SetBit(state485,MASK_485_TX); changed485=1; ls.mb_txled_delay=MB_RXTX_LED_DELAY;}
void HW485_RXcplt(){SetBit(state485,MASK_485_RX); changed485=1; ls.mb_rxled_delay=MB_RXTX_LED_DELAY;}
void HW485_ERevnt(){SetBit(state485,MASK_485_ER); changed485=1; ls.mb_erled_delay=MB_EROR_LED_DELAY;}

//copy data from Modbus.u8Buffer to the local RX and TX buffers
//MBSlave.ulTaskNotifyTake
void HW485_RXevnt(){
	if (!hMB.u8BufferSize) return;
		memset(ls.cmdRXBuf,0,MB_CMD_MAX_LEN);
		ls.cmdRXBufsz=hMB.u8BufferSize;
		memcpy(ls.cmdRXBuf,(char*)hMB.u8Buffer,hMB.u8BufferSize);
}

//sendTxBuffer.ulTaskNotifyTake
void HW485_TXevnt(){
	if (!hMB.u8BufferSize) return;
		memset(ls.cmdTXBuf,0,MB_CMD_MAX_LEN);
		ls.cmdTXBufsz=hMB.u8BufferSize;
		memcpy(ls.cmdTXBuf,(char*)hMB.u8Buffer,hMB.u8BufferSize);
	ls.rxtx=1; //parse _only_after_ both RX and TX
}

uint8_t  MBdataTxtCurLine;	//current log line, to GUI->
//Parse both buffers for LCD 6 lines X 64 symb +\n +0
//Convert each byte to HEX+" ", cut long line, add "\n"
//repeat for RX and then for TX, two line
void ParceMBtxt(){
	memset( MBdataTxt[ls.txt_line],0,MB_TXT_LINE_SZ);
	sprintf(MBdataTxt[ls.txt_line],"%05d RX: ", MBdataAIs[MB_AI_MOTOH]);
	char chank[12];
	for (uint8_t i=0; i<ls.cmdRXBufsz; i++){
		sprintf (chank,"%2.2X ",ls.cmdRXBuf[i]);
		strcat(MBdataTxt[ls.txt_line],chank);
		if (i*3 == MB_TXT_LINE_SZ-20){
			strcat(MBdataTxt[ls.txt_line],"...");//cut long line
			break;
		}
	}
	strcat(MBdataTxt[ls.txt_line],"\n");
	ls.txt_line++;

	memset( MBdataTxt[ls.txt_line],0,MB_TXT_LINE_SZ);
	sprintf(MBdataTxt[ls.txt_line],"%05d TX: ", MBdataAIs[MB_AI_MOTOH]);
	for (uint8_t i=0; i<ls.cmdTXBufsz; i++){
		sprintf (chank,"%2.2X ",ls.cmdTXBuf[i]);
		strcat(MBdataTxt[ls.txt_line],chank);
		if (i*3 > MB_TXT_LINE_SZ-20){
			strcat(MBdataTxt[ls.txt_line],"...");
			break;
		}
	}
	strcat(MBdataTxt[ls.txt_line],"\n");

	ls.txt_line=(ls.txt_line>MB_TXT_LINE_NUM-2)? 0 : ls.txt_line+1;
	MBdataTxtCurLine=ls.txt_line;	//tell GUI start which line

	ls.rxtx=0;	  //flag parse ready
	SetBit(state485,MASK_485_MB);//flag redraw text widget
	changed485=1; //flag 485 info changed
}


// Main Laser task, each 250ms---------------------------
void LaserTick(){
	mt++;	//250ms tick, check main->myTask3

	//MB data changed -> update gui widgets every 1/4s
	//TODO make slow regresh
	changed485=1;
	if (ls.rxtx) ParceMBtxt();

	//On/off laser via MB and preheat delay
	if (!ls.on &&  GetCoilDO(MB_DO_LAS_ON)) LaserOn ();
	if ( ls.on && !GetCoilDO(MB_DO_LAS_ON)) LaserOff();
	if ( ls.on && ls.hot_delay){	//preheat
		ls.hot_delay--;
		if (!ls.hot_delay) LaserHot();
	}

	if (!(mt%MT5SEC)){	//each half sec
		//stub
	}

	//Counters moto amd laser pulses
	if (!(mt%MT1SEC)){	//each sec
		MBdataAIs[MB_AI_MOTOH]++;	//Moto Hours

		if (ls.hot && ls.on) MBdataAIs[MB_AI_PULSC]+=LAS_PC_INC; //Pulse count

		//simulate values around preseted
		if (MBdataAIs[MB_AI_PULSC])
			MBdataAIs[MB_AI_ERROR]=\
			(MBdataAIs[MB_AI_PULSC]%(LAS_PC_INC*39))?0:(rand()%(2*16+1)+1); //er simu MB_AO_ERROR

		changedMB=1;
	}

	//simulate AI values changed -> update gui widgets "got AI values"
	if (ls.on && !(mt%MT4SEC)){
		MBdataAIs[MB_AI_PW]=MBdataAOs[MB_AO_PW]+rand_dev(10);
		//MBdataAOs[MB_AO_PD]+=rand_dev(10);
		MBdataAIs[MB_AI_PC]=MBdataAOs[MB_AO_PC]+rand_dev(5);
		MBdataAIs[MB_AI_CV]=MBdataAOs[MB_AO_CV]+rand_dev(30);

		//changedMB=1;	//already at 1sec
	}

	//HW button deal
	if (btn_usr){	//usr but
		if (ls.on) LaserOff(); else LaserOn();
		changedON=1; //call gui
		btn_usr=0;
	}

	//changedMB=1;	//redraw GUI MB Coils and Regs each 250ms
}
