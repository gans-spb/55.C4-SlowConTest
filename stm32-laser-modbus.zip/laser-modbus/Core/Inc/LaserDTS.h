/*
 * LaserDTS.h
 *
 *  Created on: Nov 2, 2021
 *      Author: eva
 */

#ifndef LASERDTS_H
#define LASERDTS_H

#include <stdint.h>
#define rand_dev(val) (rand()%(2*val+1)-val)

uint8_t btn_usr;    //HW backend for GPIO button and led state
uint8_t changedON;	//ON/OFF was changed
uint8_t changed485;	//MB port RS485 was changed
uint8_t changedMB;  //MB data buffer was changed
uint8_t state485;   //MB485 state bits

#include "Modbus.h"
modbusHandler_t hMB;//modbus struct header

#define MBdataSize 20				//data size for each data buf, must be 1-270Fh
uint16_t MBdataDOs[MBdataSize]; ///16+1]; //1bit binary buffer less than reg buffer /16
uint16_t MBdataDIs[MBdataSize]; ///16+1];
uint16_t MBdataAOs[MBdataSize];		 //16bit reg buffers
uint16_t MBdataAIs[MBdataSize];
uint8_t  slave_id[4];                //ID buffer fo test ID data

void LaserInit();
void LaserOn  ();
void LaserOff ();
void TogLaser();	   //GUI->HW
void Tog485();		   //GUI->HW
void HW485 (uint8_t);  //HW->Laser

void LaserTick();
uint32_t mt;	//master tick 250ms Task3

#define MT5SEC	2  //each 0.5 sec
#define MT1SEC	4  //each 1 sec
#define MT4SEC	16 //each 4 sec

#define LAS_PC_INC		3//pulse count increment 3Hz
#define LAS_ON_DELAY	6//delay to ON at 250ms tick

#define MB_RXTX_LED_DELAY   2	//delay for led RX TX
#define MB_EROR_LED_DELAY   4	//delay for led Eror

#define MB_CMD_MAX_LEN  32	//longest RX or TX Modus telegram
#define MB_TXT_LINE_SZ  66
#define MB_TXT_LINE_NUM 6
char  MBdataTxt[MB_TXT_LINE_NUM][MB_TXT_LINE_SZ];	         //log formatted text

typedef struct {
	uint8_t on;     //on/off
	uint8_t hot;    //preheated
	uint8_t pulse;  //pulse mode
	uint8_t extsy;  //ext sync
	uint8_t on485;  //485 on/off by irq

	uint8_t hot_delay;  //pre haet delay
	uint8_t rxtx;    	//rxtx nvic callback event
	uint8_t txt_line;   //current txt line num

	uint8_t mb_rxled_delay;   //current delay for RX TX led
	uint8_t mb_txled_delay;   //current delay for RX TX led
	uint8_t mb_erled_delay;   //current delay for Error led


	char    cmdRXBuf[MB_CMD_MAX_LEN ];
	uint8_t cmdRXBufsz;
	char    cmdTXBuf[MB_CMD_MAX_LEN ];
	uint8_t cmdTXBufsz;

} laserState_TypeDef;

#endif //LASERDTS_H
