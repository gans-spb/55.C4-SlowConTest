/* LaserMB.h
 * DTS Laser Modbus defenitions
 * for 55.C4 DTS Laser, ITER CODAC
 */

#ifndef LASERDTSMB_H
#define LASERDTSMB_H

//Modbus buffer
/* Modbus protocol description
Addr--------------------------------      R   W   Wm
     1 - (10 000-1) + 0-270Fh RW  DO  1b  01  05  15  Coil
10 001 - (20 000-1) + 0-270Fh Ro  DI  1b  02          Input
30 001 - (40 000-1) + 0-270Fh Ro  AI 16b  04          Input Reg
40 001 - (50 000-1) + 0-270Fh RW  AO 16b  03  06  16  Holding Reg

01 DO read	 Read Coil Status
02 DI read	 Read Input Status
03 AO read	 Read Holding Registers
04 AI read	 Read Input Registers
05 DO write	 Force Single Coil
06 AO write	 Preset Single Register
15 DO mwrite Force Multiple Coils
16 AO mwrite Preset Multiple Registers
11           Report ID

Start, Addr 8b, Func 8b, Data 8b*n, CRC  8b*2, Stop (S+S or P+S)
*/

/* DTS Laser Modbus buffer description
 * DO 0=LasOn, 1=PulsMode, 2=ExtSync
 * DI 0=LasHot
 * AO 0=Pulse_width, 1=Pulse_Delay, 2=Pump_current, 3=Cap_voltage //set
 * AI 5=Moto_Hours,  6=Pulse_count,               , 9=error_num
 * AI 0=Pulse_width,              , 2=Pump_current, 3=Cap_voltage //measured
 * */

//define TOUCHGFXDIZ for TouchGFX simulator Ok compile
#ifdef TOUCHGFXDIZ

#define MB_TXT_LINE_SZ  66
#define MB_TXT_LINE_NUM 6

//extern "C" {
extern uint16_t MBdataDOs[];
extern uint16_t MBdataDIs[];
extern uint16_t MBdataAOs[];
extern uint16_t MBdataAIs[];
extern char     MBdataTxt[][MB_TXT_LINE_SZ];
extern uint8_t  MBdataTxtCurLine;
extern uint8_t  state485;
//}

#else //TOUCHGFXDIZ
#define MBdataSize 20
uint16_t MBdataDOs[MBdataSize];
uint16_t MBdataDIs[MBdataSize];
uint16_t MBdataAOs[MBdataSize];
uint16_t MBdataAIs[MBdataSize];
#endif //TOUCHGFXDIZ

//Laser symantica for coils and regs
#define MB_DO_LAS_ON    0,0 //turn on laser
#define MB_DO_PULSE_MOD 0,1 //pulse/single mode
#define MB_DO_EXT_SYNC  0,2 //external sync
#define MB_DI_LAS_HOT   0,0 //laser preheated and ready

#define MB_AI_MOTOH 5	//Moto_Hours get
#define MB_AI_PULSC 6	//Moto_Hours get
#define MB_AI_ERROR 9	//Error number get

#define MB_AO_PW    0	//Pulse_width set
#define MB_AI_PW    0	//Pulse_width get
#define MB_AO_PD    1	//Pulse_delay set
//#define MB_AO_PD    1	//Pulse_delay get [not possible]
#define MB_AO_PC    2	//Pump_current set
#define MB_AI_PC    2	//Pump_current get
#define MB_AO_CV    3	//Cap_voltage set
#define MB_AI_CV    3	//Cap_voltage get

//general getter and setter
#define  SetBit(a,b) (a |= (1UL<<b))
#define  ResBit(a,b) (a &=~(1UL<<b))
#define  TogBit(a,b) (a ^=~(1UL<<b))
#define  GetBit(a,b) (a &  (1UL<<b))

//Coil and reg getter and setter
inline void SetCoilDO   (uint8_t byte, uint8_t bit)  {SetBit(MBdataDOs[byte],bit);}
inline void SetCoilDI   (uint8_t byte, uint8_t bit)  {SetBit(MBdataDIs[byte],bit);}
inline void ResetCoilDO (uint8_t byte, uint8_t bit)  {ResBit(MBdataDOs[byte],bit);}
inline void ResetCoilDI (uint8_t byte, uint8_t bit)  {ResBit(MBdataDIs[byte],bit);}
inline uint8_t GetCoilDO(uint8_t byte, uint8_t bit) {return GetBit(MBdataDOs[byte],bit);}
inline uint8_t GetCoilDI(uint8_t byte, uint8_t bit) {return GetBit(MBdataDIs[byte],bit);}

//Predef for 485 states
#define MASK_485_ON	0x0	//laser on/off [not in use, see ls.on485]
#define MASK_485_TX	0x1 //UART TX event
#define MASK_485_RX	0x2 //UART RX event
#define MASK_485_ER	0x3 //UART ER event
#define MASK_485_MB	0x4 //UART MB parsed

//desc for fucntions for GUI
void HW485_ONevnt();
void HW485_TXcplt();
void HW485_RXcplt();
void HW485_ERevnt();
void HW485_RXevnt();
void HW485_TXevnt();

#endif //LASERDTSMB_H
